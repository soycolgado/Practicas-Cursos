<nav>
	<ul>
		<li><a href="index.php">Registro</a></li>
		<li><a href="index.php?action=ingresar">Ingreso</a></li>
		<li><a href="index.php?action=usuarios">Usuarios</a></li>
		<li><a href="index.php?action=salir">Salir</a></li>
	</ul>
</nav>