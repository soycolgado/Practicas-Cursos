<h1>USUARIOS</h1>

	<table border="1">
		
		<thead>
			
			<tr>
				<th>Usuario</th>
				<th>Contraseña</th>
				<th>Email</th>
				<th></th>
				<th></th>

			</tr>

		</thead>

		<tbody>
			
			<tr>
				<td>juan</td>
				<td>1234</td>
				<td>juan@hotmail.com</td>
				<td><button>Editar</button></td>
				<td><button>Borrar</button></td>
			</tr>

		</tbody>



	</table>