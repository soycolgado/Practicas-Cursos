var app = angular.module('universidadApp',[ ]);

app.controller('mainCtrl', ['$scope','$http', function($scope,$http){
  

}]);